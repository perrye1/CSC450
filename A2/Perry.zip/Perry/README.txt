Compile and execute the java file at the command line from inside the "java" directory as follows:

>javac A2_Queries_NOSQL.java
>java A2_Queries_NOSQL